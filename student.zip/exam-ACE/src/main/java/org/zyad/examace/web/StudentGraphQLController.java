package org.zyad.examace.web;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;

@Controller
@AllArgsConstructor
public class StudentGraphQLController {
}
