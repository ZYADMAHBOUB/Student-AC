package org.zyad.examace.service;

import org.springframework.stereotype.Service;
import org.zyad.examace.dto.StudentDTO;
import org.zyad.examace.entity.Student;


public interface StudentService {
  public StudentDTO saveStudent(StudentDTO studentDTO);
  public StudentDTO getStudentByDateNaissance(String dateNaissance);



}
