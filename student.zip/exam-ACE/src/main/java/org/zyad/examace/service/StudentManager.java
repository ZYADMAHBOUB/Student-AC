package org.zyad.examace.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.zyad.examace.dto.StudentDTO;
import org.zyad.examace.entity.Student;
import org.zyad.examace.mappers.StudentMapper;
import org.zyad.examace.repositories.StudentRepository;

@Service
@AllArgsConstructor
public class StudentManager implements StudentService {
    StudentRepository studentRep;
    StudentMapper mapper;

    @Override
    public StudentDTO saveStudent(StudentDTO studentDTO) {
        Student student1 = mapper.fromStudentDTOtoStudent(studentDTO);
        student1 = studentRep.save(student1);
        return mapper.fromStudenttoStudentDTO(student1);
    }

    @Override
    public StudentDTO getStudentByDateNaissance(String dateNaissance) {
        return mapper.fromStudenttoStudentDTO(studentRep.getStudentByDateNaissance(dateNaissance));
    }
}
